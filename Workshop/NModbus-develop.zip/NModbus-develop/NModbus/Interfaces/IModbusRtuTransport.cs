﻿namespace NModbus
{
    public interface IModbusRtuTransport : IModbusSerialTransport
    {
        
    }
}