﻿namespace NModbus
{
    public interface IModbusAsciiTransport : IModbusSerialTransport
    {
        
    }
}